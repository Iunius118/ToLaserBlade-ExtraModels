package com.github.iunius118.tolaserblade.registry;

import com.github.iunius118.tolaserblade.Constants;
import com.github.iunius118.tolaserblade.block.LBBlueprintBlock;
import com.github.iunius118.tolaserblade.block.ModBlocks;
import com.github.iunius118.tolaserblade.item.ModItems;
import com.github.iunius118.tolaserblade.item.component.ModDataComponents;
import com.github.iunius118.tolaserblade.item.crafting.*;
import com.github.iunius118.tolaserblade.menu.ModMenuTypes;
import com.github.iunius118.tolaserblade.platform.Services;
import com.github.iunius118.tolaserblade.sounds.ModSoundEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ModRegistries {
    private static ModRegistryObject<Item> LASER_BLADE;

    public static void registerGameObjects() {
        // Blocks
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.BLOCK, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.Blocks.BL_BLUEPRINT, () -> ModBlocks.BL_BLUEPRINT);
                });
        // Block types
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.BLOCK_TYPE, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.BlockTypes.BL_BLUEPRINT, () -> LBBlueprintBlock.CODEC);
                });
        // Items
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.ITEM, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.Items.BL_BLUEPRINT, () -> ModItems.BL_BLUEPRINT);

                    LASER_BLADE = r.register(Constants.Items.LASER_BLADE, () -> ModItems.LASER_BLADE);
                    r.register(Constants.Items.LASER_BLADE_FP, () -> ModItems.LASER_BLADE_FP);

                    r.register(Constants.Items.LB_CASING, () -> ModItems.LB_CASING);
                    r.register(Constants.Items.LB_CASING_FP, () -> ModItems.LB_CASING_FP);
                    r.register(Constants.Items.LB_BATTERY, () -> ModItems.LB_BATTERY);
                    r.register(Constants.Items.LB_MEDIUM, () -> ModItems.LB_MEDIUM);
                    r.register(Constants.Items.LB_EMITTER, () -> ModItems.LB_EMITTER);
                });
        // Data component types
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.DATA_COMPONENT_TYPE, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.DataComponents.MODEL, () -> ModDataComponents.MODEL);
                    r.register(Constants.DataComponents.BLEND_MODES, () -> ModDataComponents.BLEND_MODES);
                });
        // Recipe types
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.RECIPE_TYPE, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.RecipeTypes.BLUEPRINT, () -> ModRecipeTypes.BLUEPRINT);
                });
        // Recipe Serializers
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.RECIPE_SERIALIZER, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.RecipeSerializers.BLENDING, () -> BlendingRecipe.SERIALIZER);
                    r.register(Constants.RecipeSerializers.COLORING, () -> ColoringRecipe.SERIALIZER);
                    r.register(Constants.RecipeSerializers.CRAFTING, () -> CraftingRecipe.SERIALIZER);
                    r.register(Constants.RecipeSerializers.ENCHANTMENT, () -> EnchantmentRecipe.SERIALIZER);
                    r.register(Constants.RecipeSerializers.REMODEL, () -> RemodelRecipe.SERIALIZER);
                    r.register(Constants.RecipeSerializers.REPAIR, () -> RepairRecipe.SERIALIZER);
                });
        // Recipe book categories
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.RECIPE_BOOK_CATEGORY, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.RecipeBookCategories.BLUEPRINT, () -> ModRecipeBookCategories.BLUEPRINT);
                });
        // Menus
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.MENU, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.Menus.BLUEPRINT, () -> ModMenuTypes.BLUEPRINT);
                });
        // Creative mode tabs
        Services.PLATFORM.createModObjectRegistry(BuiltInRegistries.CREATIVE_MODE_TAB, Constants.MOD_ID)
                .registerObjects(r -> {
                    r.register(Constants.CreativeModeTabs.MAIN, ModRegistries::createMainCreativeModeTab);
                });
        // Sound events
        ModSoundEvents.register();
    }

    private static CreativeModeTab createMainCreativeModeTab() {
        return Services.PLATFORM.createCreativeModeTabBuilder()
                .title(Component.translatable(Constants.CreativeModeTabs.TITLE_MOD_MAIN))
                // Check whether the mod items exist
                .icon(() -> LASER_BLADE.isBound() ? new ItemStack(LASER_BLADE.value()) : ItemStack.EMPTY)
                .displayItems((params, output) -> {
                    // Check whether the mod items exist
                    if (!LASER_BLADE.isBound()) return;

                    for (Item i : ModItems.ITEMS) {
                        output.accept(i);
                    }
                })
                .build();
    }

    private ModRegistries() {}
}
