package com.github.iunius118.tolaserblade.item.enchantment;

import com.github.iunius118.tolaserblade.Constants;
import com.github.iunius118.tolaserblade.tag.ModTags;
import net.minecraft.advancements.criterion.EntityPredicate;
import net.minecraft.advancements.criterion.EntityTypePredicate;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentEffectComponents;
import net.minecraft.world.item.enchantment.LevelBasedValue;
import net.minecraft.world.item.enchantment.effects.AddValue;
import net.minecraft.world.item.enchantment.effects.EnchantmentAttributeEffect;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemEntityPropertyCondition;

public class ModEnchantments {

    public static void bootstrap(BootstrapContext<Enchantment> ctx) {
        HolderGetter<Item> items = ctx.lookup(Registries.ITEM);
        HolderGetter<Enchantment> enchantments = ctx.lookup(Registries.ENCHANTMENT);
        HolderGetter<EntityType<?>> entityTypes = ctx.lookup(Registries.ENTITY_TYPE);

        // Define and register enchantments
        ctx.register(Constants.Enchantments.LASER_BLADE,
                Enchantment
                        .enchantment(
                                Enchantment.definition(
                                        items.getOrThrow(ModTags.Items.LASER_BLADE_ENCHANTABLE),
                                        10,
                                        5,
                                        Enchantment.dynamicCost(1, 11),
                                        Enchantment.dynamicCost(21, 11),
                                        1,
                                        EquipmentSlotGroup.MAINHAND
                                )
                        )
                        .withEffect(EnchantmentEffectComponents.ATTRIBUTES,
                                new EnchantmentAttributeEffect(
                                        Constants.Attributes.LASER_BLADE_ATTACK_DAMAGE,
                                        Attributes.ATTACK_DAMAGE,
                                        LevelBasedValue.perLevel(2.4F),
                                        AttributeModifier.Operation.ADD_VALUE
                                )
                        )
                        .withEffect(EnchantmentEffectComponents.ATTRIBUTES,
                                new EnchantmentAttributeEffect(
                                        Constants.Attributes.LASER_BLADE_ATTACK_SPEED,
                                        Attributes.ATTACK_SPEED,
                                        LevelBasedValue.perLevel(0.2F),
                                        AttributeModifier.Operation.ADD_VALUE
                                )
                        )
                        .build(Constants.Enchantments.LASER_BLADE.identifier())
        );
        ctx.register(Constants.Enchantments.LIGHT_ELEMENT,
                Enchantment
                        .enchantment(
                                Enchantment.definition(
                                        items.getOrThrow(ModTags.Items.LASER_BLADE_ENCHANTABLE),
                                        5,
                                        5,
                                        Enchantment.dynamicCost(5, 8),
                                        Enchantment.dynamicCost(25, 8),
                                        2,
                                        EquipmentSlotGroup.MAINHAND
                                )
                        )
                        .withEffect(
                                EnchantmentEffectComponents.DAMAGE,
                                new AddValue(LevelBasedValue.perLevel(4F)),
                                LootItemEntityPropertyCondition.hasProperties(
                                        LootContext.EntityTarget.THIS,
                                        EntityPredicate.Builder.entity().entityType(EntityTypePredicate.of(entityTypes,
                                                ModTags.EntityTypes.SENSITIVE_TO_LASER_BLADE))
                                )
                        )
                        .exclusiveWith(enchantments.getOrThrow(EnchantmentTags.DAMAGE_EXCLUSIVE))
                        .build(Constants.Enchantments.LIGHT_ELEMENT.identifier())
        );
    }

    public static void bootstrapOptional(BootstrapContext<Enchantment> ctx) {
        HolderGetter<Item> items = ctx.lookup(Registries.ITEM);

        // Define and register optional enchantments
        ctx.register(Constants.Enchantments.REPULSIVE_FORCE,
                Enchantment
                        .enchantment(
                                Enchantment.definition(
                                        items.getOrThrow(ModTags.Items.LASER_BLADE_ENCHANTABLE),
                                        5,
                                        3,
                                        Enchantment.dynamicCost(5, 20),
                                        Enchantment.dynamicCost(55, 20),
                                        2,
                                        EquipmentSlotGroup.MAINHAND
                                )
                        )
                        .withEffect(EnchantmentEffectComponents.KNOCKBACK,
                                new AddValue(LevelBasedValue.perLevel(0F, 1F))
                        )
                        .build(Constants.Enchantments.REPULSIVE_FORCE.identifier())
        );
    }
}
